/*Programmer:   Joshua Jones
 Assignment: Homework 1_HelloWorld
 Filename: Hmwrk1_HelloWorld.cpp
 Creation Date: 8-26-2020
 Description:   This program outputs the line "Hello World"
 */

#include<iostream> //This line of code causes the contents of another file
                    //to be inserted to the program

using namespace std;

//The following line of code begins every C++ program.
int main(int argc, char** argv) {
    cout<<"Hello world."<<endl;

    return 0;
}

